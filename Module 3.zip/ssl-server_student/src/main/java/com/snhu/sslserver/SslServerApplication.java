package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SslServerApplication {

    /*
     * Default value used when no data is provided.
     */
    private static final String DEFAULT_DATA =
            "Kaitlyn OConnell CS-499 Module 3";

    /*
     * Input validation - character limits
     */
    private static final int MAX_INPUT_LENGTH = 256;

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    /*
     * The /hash endpoint accepts an optional data parameter.
     *
     * Example:
     * /hash?data=Hello%20World
     *
     * If no data parameter is provided, the default value is used.
     * 
     * Removed hard code from the original K.O CS-305 Project two. client input can now be retrieved. 
     */
    @GetMapping("/hash")
    public ResponseEntity<String> checksum(
            @RequestParam(name = "data", required = false) String data) {

        String input = validateInput(data);

        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            byte[] hash =
                    digest.digest(
                            input.getBytes(StandardCharsets.UTF_8));

            StringBuilder hex = new StringBuilder();

            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }

            /*
             * Escape the input before displaying it in the HTML response.
             */
            String safeInput = escapeHtml(input);

            return ResponseEntity.ok(
                    "<h2>Original Data</h2>"
                    + safeInput
                    + "<br><br>"
                    + "<h2>SHA-256 Hash</h2>"
                    + hex);

        } catch (NoSuchAlgorithmException e) {

            /*
             * SHA-256 
             * Return a controlled error if it is not available.
             */
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: SHA-256 algorithm unavailable.");
        }
    }

    /*
     * Checks the input before it is processed.
     * input paramaeters on field exceptions such as length, type of input and characters
     */
    private String validateInput(String data) {

        if (data == null) {
            return DEFAULT_DATA;
        }

        String trimmed = data.trim();

        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException(
                    "The field cannot be empty.");
        }

        if (trimmed.length() > MAX_INPUT_LENGTH) {
            throw new IllegalArgumentException(
                    "There can be no more than "
                    + MAX_INPUT_LENGTH
                    + " characters.");
        }

        return trimmed;
    }

    /*
     * Allows users to use the values as input instead of the site seeing them as HTML entities. this ensures the input reflects the output. 
     */
    private String escapeHtml(String input) {

        return input
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    /*
     * Returns a 400 response when invalid input is provided.
     * This is a controlled error, so that a random error is not thrown. 
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleInvalidInput(
            IllegalArgumentException e) {

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body("Error: " + e.getMessage());
    }
}
