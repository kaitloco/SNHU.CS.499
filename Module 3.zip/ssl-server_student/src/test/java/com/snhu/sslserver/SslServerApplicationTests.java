package com.snhu.sslserver;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class SslServerApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    /*
     * Confirms that the Spring application can start.
     * Does not confirm if API works 
     */
    @Test
    void contextLoads() {
    }

    /*
     * Tests the original behavior when no data parameter is provided.
     */
    @Test
    void hashEndpoint_withoutParameter_usesDefaultData()
            throws Exception {

        mockMvc.perform(get("/hash"))
                .andExpect(status().isOk())
                .andExpect(
                        content().string(
                                containsString(
                                        "Kaitlyn OConnell CS-305 Project Two")))
                .andExpect(
                        content().string(
                                containsString("SHA-256 Hash")));
    }

    /*
     * Sends request to endpoint and verifies response. Tests endpoint behavior 
     * 
     */
    @Test
    void hashEndpoint_withValidInput_returnsExpectedData()
            throws Exception {

        mockMvc.perform(
                get("/hash")
                        .param("data", "Hello World"))
                .andExpect(status().isOk())
                .andExpect(
                        content().string(
                                containsString("Hello World")))
                .andExpect(
                        content().string(
                                containsString("SHA-256 Hash")));
    }

    /*
     * Tests that the API generates the expected SHA-256 hash. Verifies cryptography 
     */
    @Test
    void hashEndpoint_withValidInput_returnsCorrectHash()
            throws Exception {

        mockMvc.perform(
                get("/hash")
                        .param("data", "Hello World"))
                .andExpect(status().isOk())
                .andExpect(
                        content().string(
                                containsString(
                                    "a591a6d40bf420404a011733cfb7b190"
                                    + "d62c65bf0bcda32b58e2c5f7b4b1e0e")));
    }

    /*
     * Tests blank input. Determines if "bad" input is handled orrectly 
     */
    @Test
    void hashEndpoint_withBlankInput_returnsBadRequest()
            throws Exception {

        mockMvc.perform(
                get("/hash")
                        .param("data", "   "))
                .andExpect(status().isBadRequest())
                .andExpect(
                        content().string(
                                containsString(
                                        "cannot be blank")));
    }

    /*
     * Tests an empty parameter.
     */
    @Test
    void hashEndpoint_withEmptyInput_returnsBadRequest()
            throws Exception {

        mockMvc.perform(
                get("/hash")
                        .param("data", ""))
                .andExpect(status().isBadRequest());
    }

    /*
     * Tests the maximum input length.
     */
    @Test
    void hashEndpoint_withInputOverLimit_returnsBadRequest()
            throws Exception {

        String tooLong = "a".repeat(257);

        mockMvc.perform(
                get("/hash")
                        .param("data", tooLong))
                .andExpect(status().isBadRequest())
                .andExpect(
                        content().string(
                                containsString(
                                        "No more than 256 characters allowed")));
    }

    /*
     * Tests that HTML characters are escaped before being
     * displayed in the response.
     */
    @Test
    void hashEndpoint_withHtmlInput_escapesHtml()
            throws Exception {

        mockMvc.perform(
                get("/hash")
                        .param(
                                "data",
                                "<script>alert('test')</script>"))
                .andExpect(status().isOk())
                .andExpect(
                        content().string(
                                containsString(
                                        "&lt;script&gt;")))
                .andExpect(
                        content().string(
                                org.hamcrest.Matchers.not(
                                        containsString(
                                                "<script>alert"))));
    }
}

